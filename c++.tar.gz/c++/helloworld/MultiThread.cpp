#include <iostream>
#include <list>
#include <algorithm>
#include <future>
#include <random>
#include <mutex>

using namespace std;

int threadFunction1(int v1[], int start, int end) {
    int sum=0;
    cout << "Thread 1 in esecuzione"<< endl;
    for (int i=start;i<=end;i++)
        sum+=v1[i];
    cout<<"Il primo risultato è: "<<sum<<endl;    
    return sum;    
}

int threadFunction2(int v1[], int start, int end) {
    int sum=0;
    cout << "Thread 2 in esecuzione"<< endl;
    for (int i=start;i<=end;i++)
        sum+=v1[i];
    cout<<"Il secondo risultato è: "<<sum<<endl;    
    return sum;    
}


int main(){
    int vettore[8]={2,4,5,9,1,23,12,91};
    future<int> future1 = async(threadFunction1, vettore, 0, 3);
    future<int> future2 = async(threadFunction2, vettore, 4, 7);

    int sum1 = future1.get();
    int sum2 = future2.get();

    cout << "Il risultato è: " << sum1+sum2 << endl;
    
    return 0;

}