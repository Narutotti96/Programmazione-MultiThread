#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

using namespace std;

class Buffer{
    public:

        void produce(int newValue) {
            lock_guard<mutex> lock (mtx);
            value=newValue;
            cv.notify_one();

            cout<<"Prodotto ok"<<endl;
        }

        void consume() {
            unique_lock<mutex> lock(mtx);
            cv.wait(lock, [this] { return value != 0; });
            cout << "Valore consumato: " << value << endl;
            value = 0;
        }

    private:
        int value=0;
        mutex mtx;
        condition_variable cv;
    
};

void producer(Buffer& buffer) {
    // Produzione di un valore
    int value = 42;
    buffer.produce(value);
}

void consumer(Buffer& buffer) {
    // Consumo del valore
    buffer.consume();
}

int main() {
    Buffer buffer;

    thread producerThread(producer, ref(buffer));
    thread consumerThread(consumer, ref(buffer));

    producerThread.join();
    consumerThread.join();

    return 0;
}