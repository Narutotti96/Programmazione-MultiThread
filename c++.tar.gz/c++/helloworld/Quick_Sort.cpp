#include <iostream>
#include <list>
#include <algorithm>
#include <future>
#include <random>
#include <mutex>

using namespace std;

template<typename T>
void stampa(list<T> lista,  typename list<T>::iterator da, typename list<T>::iterator a)
{

  for (auto it=da; it!=a; it++)
      cout << *it << " ";

  cout << "\n";
}

template<typename T>
list<T> parallel_quick_sort(list<T> lista_disordinata, mutex &m)
{
  //cout << "Thread id: " << this_thread::get_id() << endl;
  static int num_thread = 2;

  if(lista_disordinata.empty()) return lista_disordinata;

  list<T> lista_ordinata;
  lista_ordinata.splice(lista_ordinata.begin(),lista_disordinata,lista_disordinata.begin());

  //reference costante al pivot per evitare copia
  //(il tipo T potrebbe essere `pesante`!
  T const& pivot=*lista_ordinata.begin();

  auto posizione_dividi_lista=partition(lista_disordinata.begin(),lista_disordinata.end(),
                                        [&](T const& t){return t<pivot;});

  list<T> minori_del_pivot;
  minori_del_pivot.splice(minori_del_pivot.end(),
                          lista_disordinata,lista_disordinata.begin(),
                          posizione_dividi_lista);

  //parte inferiore ordinata
  list<T> minori_del_pivot_ordinati {};
  list<T> maggiori_del_pivot_ordinati {};


  if (minori_del_pivot.size() > 100000 && num_thread<30)
  {
      m.lock();
        num_thread++;
      m.unlock();

      future< list<T> > minori_del_pivot_ordinati(async(launch::async,
                                                  &parallel_quick_sort<T>,move(minori_del_pivot), ref(m)));

      maggiori_del_pivot_ordinati=parallel_quick_sort(move(lista_disordinata), ref(m));

      lista_ordinata.splice(lista_ordinata.end(),maggiori_del_pivot_ordinati);
      lista_ordinata.splice(lista_ordinata.begin(),minori_del_pivot_ordinati.get());

      m.lock();
        num_thread--;
      m.unlock();
  }
  else
  {
    minori_del_pivot_ordinati = parallel_quick_sort(move(minori_del_pivot), ref(m));
    maggiori_del_pivot_ordinati=parallel_quick_sort(move(lista_disordinata), ref(m));

    lista_ordinata.splice(lista_ordinata.end(),maggiori_del_pivot_ordinati);
    lista_ordinata.splice(lista_ordinata.begin(),minori_del_pivot_ordinati);
  }

  return lista_ordinata;
}

list<double> crea_lista(int quanti)
{
  list<double> lista {};

  cout << "Creazione lista iniziata ...\n";

  default_random_engine generator;
  uniform_real_distribution<double> distribution(0.0,1000.0);

  for(int i=0; i<quanti; i++)
    lista.push_front(distribution(generator));

    cout << "Creazione lista terminata ...\n";
  return lista;
}

template<typename T>
list<T> sequential_quick_sort(list<T> lista_disordinata)
{
  if(lista_disordinata.empty()) return lista_disordinata;

  list<T> lista_ordinata;
  lista_ordinata.splice(lista_ordinata.begin(),lista_disordinata,lista_disordinata.begin());

  //reference costante al pivot per evitare copia
  //(il tipo T potrebbe essere `pesante`!
  T const& pivot=*lista_ordinata.begin();

  auto posizione_dividi_lista=partition(lista_disordinata.begin(),lista_disordinata.end(),
                                        [&](T const& t){return t<pivot;});

  list<T> minori_del_pivot;
  minori_del_pivot.splice(minori_del_pivot.end(),
                          lista_disordinata,lista_disordinata.begin(), posizione_dividi_lista);

  //parte inferiore ordinata
  auto minori_del_pivot_ordinati{sequential_quick_sort(move(minori_del_pivot))};

  //parte superiore ordinata
  auto maggiori_del_pivot_ordinati{sequential_quick_sort(move(lista_disordinata))};

  lista_ordinata.splice(lista_ordinata.end(),maggiori_del_pivot_ordinati);
  lista_ordinata.splice(lista_ordinata.begin(),minori_del_pivot_ordinati);

  return lista_ordinata;
}

template<typename T>
string check_lista_ordinata(list<T> lista)
{
  bool ordinata = true;


  for (auto it=lista.begin(); it!= prev(lista.end()) ; it++)
  {
    if (*it > *next(it) )
    {
      ordinata = false;
      break;
    }
  }

  return ordinata ? "Ordinamento confermato" : "Ordinamento fallito!";
}

int main()
{



    list<double> lista_disordinata = crea_lista(10000000);
    //stampa<double>(lista_disordinata, lista_disordinata.begin(), next(lista_disordinata.begin(), 8));


    cout << "inizio algoritmo sequenziale ...\n";
    auto inizio = chrono::high_resolution_clock::now();
    list<double> lista_ordinata = sequential_quick_sort<double>(lista_disordinata);
    auto fine = chrono::high_resolution_clock::now();

    auto int_ms = chrono::duration_cast<chrono::milliseconds>(fine - inizio).count();
    cout << "durata algoritmo sequenziale: " << int_ms << " ms\n";

    mutex m;

    cout << "inizio algoritmo parallelo ...\n";
    inizio = chrono::high_resolution_clock::now();
    lista_ordinata = parallel_quick_sort<double>(lista_disordinata, ref(m));
    fine = chrono::high_resolution_clock::now();

    int_ms = chrono::duration_cast<chrono::milliseconds>(fine - inizio).count();
    cout << "durata algoritmo parallelo: " << int_ms << " ms\n";



    return 0;
}




