#include <iostream>
#include <thread>
#include <chrono>
#include <fstream>
#include <cmath>

using namespace std;

bool isPrimo(int n){
    int divisore=2;
    bool test=true;
    while(divisore<(int)sqrt(n)+1){
        if(n%divisore==0)
        {test=false; break;}
        divisore++;
    }
    return test;
}

void primi_su_file(string nome_file, int da, int a){
    ofstream scrivi(nome_file);
    for (int num = da; num <= a; num++)
        if (isPrimo(num))
            scrivi<<num<<endl;
    scrivi.close(); scrivi.clear();
}

int main(){

const int QUANTI=5*1000000;
const int NTHREADS=2;

auto inizio=chrono::high_resolution_clock::now();
for (int t = 0; t < NTHREADS; t++)
    primi_su_file(string {"primi"}+to_string(t)+ string{".txt"},t==0 ? 2 : t*QUANTI/NTHREADS+1, (t+1)*QUANTI/NTHREADS);
auto fine=chrono::high_resolution_clock::now();
auto int_ms_seq=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();

inizio=chrono::high_resolution_clock::now();  
thread vt[NTHREADS];

for (int t = 0; t < NTHREADS; t++)
   vt[t] =thread{primi_su_file,string{"primi"}+to_string(t)+string{".txt"}, t==0 ? 2 : t*QUANTI/NTHREADS+1, (t+1)*QUANTI/NTHREADS};
for (int i = 0; i < NTHREADS; i++)   
   vt[i].join();
fine=chrono::high_resolution_clock::now();
auto int_ms_conc=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();
cout<<"Durata algoritmo sequenziale: "<<int_ms_seq<< " ms\n";
cout<<"Durata algorimo concorrente: "<<int_ms_conc<<" ms\n";

}