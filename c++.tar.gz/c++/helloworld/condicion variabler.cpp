#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

using namespace std;

class Semaphore {
public:
    explicit Semaphore(int count) : count_(count) {}

    void acquire() {
        unique_lock<mutex> lock(mutex_);
        while (count_ == 0) {
            cv_.wait(lock);
        }
        count_--;
    }

    void release() {
        lock_guard<mutex> lock(mutex_);
        count_++;
        cv_.notify_one();
    }

private:
    int count_;
    mutex mutex_;
    condition_variable cv_;
};

int sharedValue = 0;
Semaphore sem(1);

void incrementSharedValue() {
    for (int i = 0; i < 100000; i++) {
        sem.acquire();
        sharedValue++;
        sem.release();
    }
}

int main() {
    thread t1(incrementSharedValue);
    thread t2(incrementSharedValue);

    t1.join();
    t2.join();

    cout << "Valore condiviso finale: " << sharedValue << endl;

    return 0;
}
