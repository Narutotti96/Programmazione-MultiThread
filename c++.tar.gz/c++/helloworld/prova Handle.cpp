#include <iostream>

class Rectangle{
    private: 
    int length;
    int width;
    
    public: 
    Rectangle(int length,int width){
        this->length=length;
        this->width=width;
    }    
    void Area(){
        std::cout<<"Area "<< length*width<<std::endl;
        }
        
    void Perimeter(){
        std::cout<<"Perimetro "<<(length+width)*2<<std::endl;
        }
    
};
 
int main(){
    int l=3;
    int h=9;
    Rectangle rettangolo(l,h);
    rettangolo.Area();
    rettangolo.Perimeter();
    return 0;
 }