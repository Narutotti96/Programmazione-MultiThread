#include <iostream>
#include <thread>
#include <chrono>
#include <fstream>
#include <cmath>

using namespace std;

void leggiParallela(int nthread,string v[]){
   string nomeFile="italiano"+to_string(nthread+1)+".txt";
   
   ifstream leggiParallelo(nomeFile);
   int quanteRighe=0;
   leggiParallelo>>quanteRighe;
   int partiDa=nthread*quanteRighe;
   while(!leggiParallelo.eof()){
leggiParallelo>>v[partiDa];
partiDa++;
   }
leggiParallelo.close(); leggiParallelo.clear();
}

void scriviParallela(int nthread, string v[],int indice_inizio, int indice_fine){
    string nomeFile="italiano_out"+to_string(nthread+1)+".txt";
    ofstream scriviParallelo(nomeFile);
    for(int i=indice_inizio;i<=indice_fine;i++)
        scriviParallelo<<v[i]<<endl;
    scriviParallelo.close(); scriviParallelo.clear();
}


int main(){
cout<<"LOAD SEQUENZIALE DA FILE AD ARRAY IN CORSO *******....\n";
auto inizio=chrono::high_resolution_clock::now();

ifstream leggiUnico("italiano.txt");

int quanteRighe=0;
leggiUnico>>quanteRighe;
string *v=new string[quanteRighe];

int numero_parole=0;
while (!leggiUnico.eof())
{
    leggiUnico>>v[numero_parole];
    numero_parole++;

}
leggiUnico.close(); leggiUnico.clear();

auto fine=chrono::high_resolution_clock::now();
auto int_ms_seq=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();
cout<<"Durata algoritmo sequenziale: "<<int_ms_seq<<" ms\n";

const int NTHREADS=2;
thread vt[NTHREADS];

inizio=chrono::high_resolution_clock::now();
for(int t=0;t<NTHREADS;t++)
    vt[t]=thread{leggiParallela,t,v};
for(int t=0;t<NTHREADS;t++)
    vt[t].join();
fine=chrono::high_resolution_clock::now();
auto int_ms_conc=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();
cout<<"Durata algorimo concorrente: "<<int_ms_conc<<" ms\n";
cout<<"SAVE SEQUENZIALE DA ARRAY A FILE in corso........\n";
inizio=chrono::high_resolution_clock::now();
ofstream scriviUnico("italiano_out.txt");
for(int i=0;i<numero_parole;i++)
    scriviUnico<<v[i]<<endl;
scriviUnico.close(); scriviUnico.clear();

fine=chrono::high_resolution_clock::now();
int_ms_seq=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();
cout<<"Durata algoritmo sequenziale: "<<int_ms_seq<<" ms\n";

cout<<"SAVE CONCORRENTE DA ARRAY A FILE in corso........\n";
inizio=chrono::high_resolution_clock::now();
int dimensione_blocco_parole=numero_parole/NTHREADS;

for(int i=0;i<NTHREADS;i++)
    vt[i]=thread {scriviParallela,i,v,i*dimensione_blocco_parole,(i+1)*dimensione_blocco_parole-1};
for(int i=0;i<NTHREADS;i++)
    vt[i].join();
    
fine=chrono::high_resolution_clock::now();
int_ms_conc=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();
cout<<"Durata SAVE algoritmo concorrente "<<int_ms_conc<<" ms\n";
delete[] v;
  return 0;
} 
