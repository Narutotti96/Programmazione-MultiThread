#include <stdio.h>
#include <CUnit/CUnit.h>
#include <stdlib.h>
#include <string.h>
#include <CUnit/Basic.h>


int init_suite(void) {
    return 0;
}

int clean_suite(void) {
    return 0;
}

void test_put_non_bloccante_buffer_pieno(void) {
    // Creazione del buffer pieno
    buffer_t* buffer = buffer_init(1);
    msg_t* expected_msg = msg_init_string("EXPECTED MSG");
    put_bloccante(buffer, expected_msg);

    // Tentativo di produzione non bloccante su buffer pieno
    msg_t* new_msg = msg_init_string("NEW MSG");
    msg_t* result = put_non_bloccante(buffer, new_msg);

    // Verifica dei risultati
    CU_ASSERT_EQUAL(result, BUFFER_ERROR);
    CU_ASSERT_PTR_EQUAL(buffer->buffer[0], expected_msg);

    // Pulizia delle risorse
    msg_destroy_string(new_msg);
    buffer_destroy(buffer);
}

int main() {
    CU_pSuite pSuite = NULL;

    // Inizializzazione del CUnit
    if (CUE_SUCCESS != CU_initialize_registry()) {
        return CU_get_error();
    }

    // Creazione del test suite
    pSuite = CU_add_suite("Test Suite", init_suite, clean_suite);
    if (NULL == pSuite) {
        CU_cleanup_registry();
        return CU_get_error();
    }

    // Aggiunta del test al test suite
    if (NULL == CU_add_test(pSuite, "Test put_non_bloccante su buffer pieno", test_put_non_bloccante_buffer_pieno)) {
        CU_cleanup_registry();
        return CU_get_error();
    }

    // Esecuzione dei test
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

    return CU_get_error();
}
