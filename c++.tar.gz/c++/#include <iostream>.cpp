#include <iostream>
#include <thread>
#include <chrono>

using namespace std;

void estrai(int quanti){
    for (int i=0; i<quanti;i++)
    rand();
}

int main(){
    const int QUANNTI=400000000;
    auto inizio=chrono::high_resolution_clock::now();
    estrai(QUANNTI);
    auto fine=chrono::high_resolution_clock::now();
    auto int_ms=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();
    cout<<"Durata algoritmo sequenziale: "<<int_ms<<"ms\n";
    const int N_THREAD_MAX=20;
    thread v_thread[N_THREAD_MAX];
    
    for (int limite=0;limite<N_THREAD_MAX;limite++){
        inizio=chrono::high_resolution_clock::now();
        for(int t=0;t<=limite;t++)
        v_thread[t]=thread(estrai,QUANNTI/(limite+1));

        for (int t=0;t<=limite;t++)
        v_thread[t].join();
        fine=chrono::high_resolution_clock::now();
        int_ms=chrono::duration_cast<chrono::milliseconds>(fine-inizio).count();
        cout<<"Durata con "<<limite+1<<" thread: "<<int_ms<<" ms/n";
    
    }
}